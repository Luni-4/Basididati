<?php
    $dbhost="localhost"; // percorso all'interno dell'host su cui è salvato dbms 
	$dbport="5432"; // porta
	$dbnome="chilosa"; // nome database
    $dbuser="postgres"; // utente che accede a dbms
    $dbpass="milano"; // password di accesso    
?> 